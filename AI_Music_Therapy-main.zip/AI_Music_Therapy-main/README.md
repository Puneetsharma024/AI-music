# AI_Music_Therapy
AI Music Therapy based on Facial Emotion Detection.
